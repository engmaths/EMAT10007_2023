G = 6.67e-11        # Gravitational constant
c = 3e8             # Speed of light (in vacuum)
h = 6.63e-34        # Planck's constant
m_e = 9.11e-31      # Mass of an electron
