# Exercise 2.1, 2.2
from math import pi as pi # pi imported

# pi = 3.142              # pi defined

def area(r):
    return 4 * pi * r**2
    
def volume(r):
    return 4 / 3 * pi * r**2
