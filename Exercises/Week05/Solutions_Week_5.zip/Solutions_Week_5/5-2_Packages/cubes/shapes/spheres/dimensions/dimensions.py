
radius = 10 # m



