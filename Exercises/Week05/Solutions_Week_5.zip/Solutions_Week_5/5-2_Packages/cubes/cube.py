# Exercise 4

def perimeter(side = 1):
    return 12 * side
