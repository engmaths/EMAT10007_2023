# Exercise 1.2
# import volumes
# print(volumes.sphere(3))

# Exercise 1.3
# from volumes import sphere
# print(sphere(3))

# Exercise 1.6
import volumes as v
import areas as a

A = 5

print('Sphere area: ', a.sphere(A))
print('Sphere volume: ', v.sphere(A))
print('Cube area: ', a.cube(A))
print('Cube volume: ', v.cube(A))



