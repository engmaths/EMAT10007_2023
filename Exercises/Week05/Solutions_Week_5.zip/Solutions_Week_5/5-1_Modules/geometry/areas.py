# Exercise 1.5

pi = 3.142

def sphere(r):
    return pi * r**2

def cube(L):
    return L**2 * 6 
