# Exercise 1.1

pi = 3.142

def sphere(r):
    return (4/3) * pi * r**3

def cube(L):
    return L**3

