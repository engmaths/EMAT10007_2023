#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  6 15:50:01 2021

@author: hemma
"""
from  math import *
#import math

def ceil(w, l):
    return w * l

def height(theta, w):
    return w/2 * tan(theta)


    
    