#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  6 15:49:29 2021

@author: hemma
"""
from  math import *
#import math

floor = 1
width = 6
length = 6

theta = pi/6

